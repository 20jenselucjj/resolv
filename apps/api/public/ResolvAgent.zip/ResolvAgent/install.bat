@echo off
setlocal EnableDelayedExpansion

echo ============================================================
echo   Resolv Agent Installer
echo ============================================================
echo.

:: Check for Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
  echo ERROR: Node.js is not installed.
  echo Please download and install Node.js from https://nodejs.org
  echo Then re-run this installer.
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo Node.js found: %NODE_VER%
echo.

:: Collect config
set /p SERVER_URL=Enter Resolv Server URL (e.g. http://192.168.1.100:3001): 
set /p AGENT_SECRET=Enter Agent Secret (from Admin > Agent Settings): 
echo.

:: Set install directory
set INSTALL_DIR=%PROGRAMDATA%\Resolv\Agent

echo Installing to: %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copy agent files
echo Copying agent files...
xcopy /E /Y /Q "%~dp0*" "%INSTALL_DIR%\" >nul

:: Write config
echo Writing config...
(
  echo {
  echo   "serverUrl": "%SERVER_URL%",
  echo   "agentSecret": "%AGENT_SECRET%"
  echo }
) > "%INSTALL_DIR%\config.json"

:: Install Node.js dependencies
echo Installing dependencies (this may take a moment)...
cd /d "%INSTALL_DIR%"
call npm install --omit=dev --quiet
if %errorlevel% neq 0 (
  echo ERROR: npm install failed. Make sure you have internet access.
  pause
  exit /b 1
)

:: Create startup script
echo Creating startup script...
(
  echo @echo off
  echo cd /d "%INSTALL_DIR%"
  echo node agent.js
) > "%INSTALL_DIR%\start-agent.bat"

:: Register with Windows Task Scheduler for auto-start
echo Registering auto-start with Task Scheduler...
schtasks /create /tn "Resolv Agent" /tr "node \"%INSTALL_DIR%\agent.js\"" /sc onlogon /rl highest /f >nul 2>&1
if %errorlevel% equ 0 (
  echo Auto-start registered.
) else (
  echo Warning: Could not register auto-start. You can start the agent manually via:
  echo   %INSTALL_DIR%\start-agent.bat
)

:: Start the agent now
echo.
echo Starting Resolv Agent...
start "Resolv Agent" /min cmd /c "cd /d \"%INSTALL_DIR%\" && node agent.js >> \"%INSTALL_DIR%\agent.log\" 2>&1"

echo.
echo ============================================================
echo   Installation complete!
echo   The agent is now running and will start automatically
echo   when you log in to Windows.
echo.
echo   Log file: %INSTALL_DIR%\agent.log
echo ============================================================
echo.
pause
