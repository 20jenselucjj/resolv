// Resolv Agent — Node.js background service
// Collects system info and reports to the Resolv ITSM server.
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const si = require('systeminformation');
const { io } = require('socket.io-client');

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
const CONFIG_FILE = path.join(__dirname, 'config.json');

function loadConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    console.error('config.json not found. Run install.bat to configure the agent.');
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
}

let config = loadConfig();
const { serverUrl, agentSecret } = config;
const API = `${serverUrl}/api`;

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let assetId = config.assetId || null;
let socket = null;

// ---------------------------------------------------------------------------
// HTTP helper (no external deps — use built-in https/http)
// ---------------------------------------------------------------------------
function request(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const fullUrl = new URL(API + urlPath);
    const mod = fullUrl.protocol === 'https:' ? require('https') : require('http');
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: fullUrl.hostname,
      port: fullUrl.port || (fullUrl.protocol === 'https:' ? 443 : 80),
      path: fullUrl.pathname + fullUrl.search,
      method,
      headers: {
        'Content-Type': 'application/json',
        'x-agent-secret': agentSecret,
        ...(assetId ? { 'x-asset-id': assetId } : {}),
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };
    const req = mod.request(opts, (res) => {
      let raw = '';
      res.on('data', (c) => (raw += c));
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); }
        catch { resolve({ status: res.statusCode, body: raw }); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// ---------------------------------------------------------------------------
// Register / checkin
// ---------------------------------------------------------------------------
async function register() {
  const hostname = os.hostname();
  const res = await request('POST', '/assets/agent/register', {
    name: hostname,
    hostname,
    agentSecret,
    agentVersion: '1.0.0',
    platform: os.platform(),
    arch: os.arch(),
  });
  if (res.status === 200 || res.status === 201) {
    assetId = res.body.asset?.id || res.body.id;
    config.assetId = assetId;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    console.log(`[Resolv Agent] Registered. Asset ID: ${assetId}`);
  } else {
    console.error('[Resolv Agent] Registration failed:', res.body);
  }
}

async function collectAndCheckin() {
  if (!assetId) { await register(); }
  if (!assetId) return;

  try {
    const [cpu, mem, disk, osInfo, net, graphics, system, bios, processes] = await Promise.all([
      si.cpu(),
      si.mem(),
      si.diskLayout(),
      si.osInfo(),
      si.networkInterfaces(),
      si.graphics(),
      si.system(),
      si.bios(),
      si.currentLoad(),
    ]);

    const disks = await si.fsSize();
    const totalDisk = disks.reduce((a, d) => a + d.size, 0);
    const usedDisk = disks.reduce((a, d) => a + d.used, 0);

    const networkAdapters = (Array.isArray(net) ? net : [net]).filter(Boolean).map((n) => ({
      adapter_name: n.iface,
      ip_address: n.ip4 || null,
      mac_address: n.mac || null,
      subnet_mask: n.ip4subnet || null,
      gateway: n.gateway4 || null,
      adapter_type: n.type || null,
      speed_mbps: n.speed || null,
      is_virtual: n.virtual || false,
      is_active: n.operstate === 'up',
    }));

    const software = await si.softwareVersions().catch(() => null);
    const installedApps = await si.osInfo().then(() => []).catch(() => []);

    const payload = {
      os_name: osInfo.distro || osInfo.platform,
      os_version: osInfo.release,
      os_build: osInfo.build || null,
      os_arch: osInfo.arch,
      ip_address: networkAdapters.find((n) => n.ip_address && !n.is_virtual)?.ip_address || null,
      mac_address: networkAdapters.find((n) => n.mac_address)?.mac_address || null,
      hostname: osInfo.hostname,
      manufacturer: system.manufacturer || null,
      model: system.model || null,
      hardware: {
        cpu_model: cpu.brand,
        cpu_manufacturer: cpu.manufacturer,
        cpu_cores: cpu.physicalCores,
        cpu_threads: cpu.cores,
        cpu_speed_mhz: Math.round((cpu.speed || 0) * 1000),
        cpu_usage_percent: Math.round(processes.currentLoad || 0),
        ram_total_gb: parseFloat((mem.total / 1e9).toFixed(2)),
        ram_used_gb: parseFloat((mem.used / 1e9).toFixed(2)),
        ram_free_gb: parseFloat((mem.free / 1e9).toFixed(2)),
        gpu_model: graphics.controllers?.[0]?.model || null,
        gpu_vram_gb: graphics.controllers?.[0]?.vram ? parseFloat((graphics.controllers[0].vram / 1024).toFixed(2)) : null,
        motherboard_manufacturer: system.manufacturer || null,
        motherboard_model: system.model || null,
        bios_version: bios.version || null,
        bios_release_date: bios.releaseDate || null,
        disk_total_gb: parseFloat((totalDisk / 1e9).toFixed(2)),
        disk_used_gb: parseFloat((usedDisk / 1e9).toFixed(2)),
        disk_free_gb: parseFloat(((totalDisk - usedDisk) / 1e9).toFixed(2)),
        disks: disk.map((d) => ({ name: d.name, size_gb: parseFloat((d.size / 1e9).toFixed(2)), type: d.type })),
        displays: graphics.displays?.map((d) => ({ model: d.model, resolution: `${d.resolutionX}x${d.resolutionY}` })) || [],
      },
      network_adapters: networkAdapters,
      current_user: os.userInfo().username,
    };

    const res = await request('POST', `/assets/${assetId}/checkin`, payload);
    if (res.status === 200) {
      console.log(`[Resolv Agent] Checkin OK at ${new Date().toISOString()}`);
    } else {
      console.warn('[Resolv Agent] Checkin failed:', res.status, res.body);
    }
  } catch (err) {
    console.error('[Resolv Agent] Checkin error:', err.message);
  }
}

// ---------------------------------------------------------------------------
// Socket.IO for real-time / remote desktop
// ---------------------------------------------------------------------------
function connectSocket() {
  if (!assetId) return;

  socket = io(serverUrl, {
    auth: { agentSecret, assetId },
    transports: ['websocket'],
    reconnectionDelay: 5000,
  });

  socket.on('connect', () => {
    console.log('[Resolv Agent] Socket connected:', socket.id);
    socket.emit('agent:join', { assetId, agentSecret });
  });

  socket.on('disconnect', () => {
    console.log('[Resolv Agent] Socket disconnected, will reconnect...');
  });

  socket.on('remote:request', async (data) => {
    console.log('[Resolv Agent] Remote desktop request from:', data.userId);
    // TODO: implement WebRTC/VNC screen capture and relay via socket
    socket.emit('remote:accept', { assetId, sessionId: data.sessionId });
  });
}

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
async function main() {
  console.log('[Resolv Agent] Starting — Server:', serverUrl);

  await register().catch((e) => console.error('Initial registration error:', e.message));
  connectSocket();
  await collectAndCheckin().catch((e) => console.error('Initial checkin error:', e.message));

  // Checkin every 5 minutes
  setInterval(() => {
    collectAndCheckin().catch((e) => console.error('Checkin error:', e.message));
  }, 5 * 60 * 1000);

  console.log('[Resolv Agent] Running. Checking in every 5 minutes.');
}

main();
